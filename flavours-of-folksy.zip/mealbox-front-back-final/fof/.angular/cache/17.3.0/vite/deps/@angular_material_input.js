import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-7R2LBTMJ.js";
import "./chunk-TRPJ5AKE.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-UVAOWIJH.js";
import "./chunk-6SBNH2ZV.js";
import "./chunk-T3D7SHP3.js";
import "./chunk-S5RE5MQJ.js";
import "./chunk-ADD4EJ76.js";
import "./chunk-SXIXOCJ4.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
